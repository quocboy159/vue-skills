export const B2C_CURRENT_USER = 'B2C_CURRENT_USER'
export const LOGGED_OUT = 'LOGGED_OUT'
export const REDIRECT_URL = 'REDIRECT_URL'
