<template>
  <resources></resources>
</template>

<script>
import Resources from '../../../containers/Resources.vue'

export default {
  name: 'TraineeResources',

  components: {
    Resources,
  },
}
</script>
