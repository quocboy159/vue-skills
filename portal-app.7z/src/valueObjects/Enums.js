export default {
  TypeOfEmail: {
    SignUp: 1,
    ForgotPassword: 2,
  },
}
