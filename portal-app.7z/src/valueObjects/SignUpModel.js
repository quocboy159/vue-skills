class SignUpModel {
  constructor(firstName, lastName, userName, reCaptchaToken) {
    this.firstName = firstName
    this.lastName = lastName
    this.userName = userName
    this.reCaptchaToken = reCaptchaToken
  }
}

export default SignUpModel
