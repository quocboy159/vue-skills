class SignInModel {
  constructor(email, password) {
    this.email = email
    this.password = password
  }
}

export default SignInModel
